require('dotenv').config();
const express = require('express');
const multer = require('multer');
const path = require('path');
const fetch = require('node-fetch');
const nodemailer = require('nodemailer');
const QRCode = require('qrcode');
const app = express();

// JSON 파싱 미들웨어 추가
app.use(express.json());

// CORS 설정
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

app.post('/api/transform', upload.single('image'), async (req, res) => {
    try {
        console.log('API 호출 시작');
        
        if (!req.file) {
            return res.status(400).json({ error: '이미지가 필요합니다.' });
        }

        if (!process.env.OPENAI_API_KEY) {
            return res.status(500).json({ error: 'OpenAI API 키가 설정되지 않았습니다.' });
        }

        console.log('이미지 처리 중...');
        const base64Image = req.file.buffer.toString('base64');
        
        // ChatGPT Vision으로 이미지 분석
        console.log('Vision API 호출 중...');
        const visionResponse = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: 'gpt-4-turbo',
                messages: [{
                    role: 'user',
                    content: [{
                        type: 'text',
                        text: `이건 사람의 증명사진 제작하는 프로그램이야. 
                                매우 정밀하게 사람은 한사람만 해줘
                                
                                [무조건 필수]
                                사람은 무조건 한명만 그리세요.
                                동양인 스타일로 머리 스타일도 따라서 그려주세요.
                                안경 착용 여부도 판단해서 그리세요.

                                data:${req.file.mimetype};base64,${base64Image}

                                [필수]
                                - 얼굴은 반드시 정면, 증명사진 처럼 명확하게
                                - 인물의 실제 특징은 유지

                                → 출력할 스타일: [선택한 스타일 이름]`
                    }, {
                        type: 'image_url',
                        image_url: { url: `data:${req.file.mimetype};base64,${base64Image}` }
                    }]
                }],
                max_tokens: 300
            })
        });

        if (!visionResponse.ok) {
            const errorText = await visionResponse.text();
            console.error('Vision API 오류:', errorText);
            return res.status(500).json({ error: 'Vision API 오류: ' + errorText });
        }

        const visionData = await visionResponse.json();
        console.log('Vision 응답:', visionData);
        
        if (!visionData.choices || !visionData.choices[0]) {
            return res.status(500).json({ error: 'Vision API 응답 오류' });
        }
        
        const description = visionData.choices[0].message.content;
        const style = req.body.style || 'ghibli';
        
        const stylePrompts = {
            ghibli: `Create an exact recreation of this scene in Studio Ghibli anime style: ${description}. IMPORTANT: Maintain the exact number of people and their individual poses, facial expressions, clothing, hair, and positions relative to each other. Use soft watercolor textures, hand-drawn animation quality, warm lighting, and Miyazaki's characteristic gentle art style. Keep all details and the number of characters identical to the original.`,
            disney: `Recreate this exact scene in Disney Pixar 3D animation style: ${description}. IMPORTANT: Preserve the exact number of people and their individual poses, expressions, outfits, and scene composition. Use bright, vibrant colors, smooth 3D rendering, family-friendly cartoon aesthetics, and Pixar's signature lighting and character design. Keep the same number of characters.`,
            anime: `Transform this scene into Japanese anime style: ${description}. IMPORTANT: Maintain the exact number of people and their individual poses, facial features, clothing, and background positions. Use vibrant anime colors, detailed character design, manga-style shading, large expressive eyes, and high-quality anime art style. Keep the same character count.`,
            cyberpunk: `Convert this scene to cyberpunk futuristic style: ${description}. IMPORTANT: Keep the exact number of people and their poses/composition but add neon lighting, holographic elements, dark urban atmosphere, sci-fi technology, glowing accents, and cyberpunk aesthetic while preserving the original scene structure and character count.`,
            fantasy: `Transform into fantasy magical style: ${description}. IMPORTANT: Maintain the exact number of people and their poses but add mystical elements, magical lighting, enchanted atmosphere, fantasy clothing details, ethereal effects, and fairy tale aesthetics while keeping the core composition and character count identical.`,
            retro: `Recreate in 80s retro synthwave style: ${description}. IMPORTANT: Keep the exact number of people and scene structure but apply neon pink/blue colors, geometric patterns, vintage 80s aesthetic, synthwave lighting, retro-futuristic elements, and nostalgic 1980s vibe. Maintain character count.`,
            horror: `Transform to gothic horror style: ${description}. IMPORTANT: Preserve the exact number of people and their poses but add dark shadows, eerie atmosphere, gothic elements, mysterious lighting, spooky mood, and horror aesthetic while maintaining the original scene structure and character count.`,
            comic: `Convert to comic book superhero style: ${description}. IMPORTANT: Keep the exact number of people and their poses but apply bold comic book colors, dynamic action lines, pop art aesthetic, comic book shading, vibrant contrasts, and superhero comic book art style. Maintain character count.`
        };

        // GPT-4o로 선택된 스타일 이미지 생성
        console.log(`${style} 스타일로 변환 중...`);
        const imageResponse = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: 'gpt-4o',
                messages: [{
                    role: 'user',
                    content: [{
                        type: 'text',
                        text: `Generate an image: ${stylePrompts[style]}`
                    }]
                }],
                max_tokens: 1000
            })
        });

        if (!imageResponse.ok) {
            const errorText = await imageResponse.text();
            console.error('Image API 오류:', errorText);
            return res.status(500).json({ error: 'Image API 오류: ' + errorText });
        }

        const imageData = await imageResponse.json();
        console.log('Image 응답:', imageData);
        
        if (!imageData.choices || !imageData.choices[0]) {
            return res.status(500).json({ error: 'Image API 응답 오류' });
        }
        
        // GPT-4o는 텍스트 응답만 제공하므로 DALL-E-3 사용
        const dalleResponse = await fetch('https://api.openai.com/v1/images/generations', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: 'dall-e-3',
                prompt: stylePrompts[style],
                n: 1,
                size: '1024x1024'
            })
        });
        
        if (!dalleResponse.ok) {
            const errorText = await dalleResponse.text();
            console.error('DALL-E API 오류:', errorText);
            return res.status(500).json({ error: 'DALL-E API 오류: ' + errorText });
        }

        const dalleData = await dalleResponse.json();
        console.log('DALL-E 응답:', dalleData);
        
        if (!dalleData.data || !dalleData.data[0]) {
            return res.status(500).json({ error: 'DALL-E API 응답 오류' });
        }
        
        res.json({
            success: true,
            style: style,
            originalDescription: description,
            transformedImageUrl: dalleData.data[0].url
        });

    } catch (error) {
        console.error('서버 오류:', error);
        res.status(500).json({ error: '서버 오류: ' + error.message });
    }
});

// 이메일 전송 API
app.post('/api/send-email', async (req, res) => {
    try {
        const { email, imageUrl, style, originalImageUrl } = req.body;
        
        if (!email || !imageUrl) {
            return res.status(400).json({ error: '이메일과 이미지 URL이 필요합니다.' });
        }
        
        // Gmail SMTP 설정
        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS
            }
        });
        
        const mailOptions = {
            from: process.env.EMAIL_USER,
            to: email,
            subject: `덕영고등학교 덕영제 사진 변환 결과 - ${style} 스타일`,
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 15px;">
                    <h1 style="color: white; text-align: center; margin-bottom: 20px;">변환 사진</h1>
                    <div style="background: white; padding: 20px; border-radius: 10px; margin: 20px 0;">
                        <h2 style="color: #333; text-align: center;">${style} 스타일 변환 결과</h2>
                        <div style="text-align: center; margin: 20px 0;">
                            <img src="${imageUrl}" alt="변환된 이미지" style="max-width: 100%; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.2);">
                        </div>
                        <p style="text-align: center; color: #666; margin-top: 20px;">학교 축제에서 만든 특별한 추억을 간직하세요!</p>
                        <p style="text-align: center; color: #999; font-size: 12px; margin-top: 20px;">이 이메일은 학교 축제 사진 변환기에서 자동으로 발송되었습니다.</p>
                    </div>
                </div>
            `
        };
        
        await transporter.sendMail(mailOptions);
        res.json({ success: true, message: '이메일이 성공적으로 전송되었습니다!' });
        
    } catch (error) {
        console.error('이메일 전송 오류:', error);
        res.status(500).json({ error: '이메일 전송에 실패했습니다.' });
    }
});

// QR 코드 생성 API
app.post('/api/generate-qr', async (req, res) => {
    try {
        const { imageUrl, style } = req.body;
        
        if (!imageUrl) {
            return res.status(400).json({ error: '이미지 URL이 필요합니다.' });
        }
        
        const qrText = `🎨 축제 사진 변환기로 만든 ${style} 스타일 작품입니다! 이미지: ${imageUrl}`;
        const qrCodeDataURL = await QRCode.toDataURL(qrText, {
            width: 200,
            margin: 2,
            color: {
                dark: '#000000',
                light: '#FFFFFF'
            }
        });
        
        res.json({ success: true, qrCode: qrCodeDataURL });
        
    } catch (error) {
        console.error('QR 코드 생성 오류:', error);
        res.status(500).json({ error: 'QR 코드 생성에 실패했습니다.' });
    }
});

// 갤러리 저장 API
app.post('/api/save-to-gallery', async (req, res) => {
    try {
        const { imageUrl, style, timestamp } = req.body;
        // 실제로는 데이터베이스에 저장하지만, 여기서는 간단히 성공 응답
        res.json({ success: true, message: '갤러리에 저장되었습니다!' });
    } catch (error) {
        res.status(500).json({ error: '갤러리 저장에 실패했습니다.' });
    }
});

// 루트 경로에서 index.html 서빙
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// CSS, JS 등 정적 파일만 서빙
app.use('/css', express.static(path.join(__dirname, 'public', 'css')));
app.use('/js', express.static(path.join(__dirname, 'public', 'js')));
app.use('/images', express.static(path.join(__dirname, 'public', 'images')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`http://localhost:${PORT}`));
